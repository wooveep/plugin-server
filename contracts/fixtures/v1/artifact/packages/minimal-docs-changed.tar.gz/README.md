D0 fixture changed docs.

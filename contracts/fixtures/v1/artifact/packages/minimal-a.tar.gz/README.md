D0 fixture only.

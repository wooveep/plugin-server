# Offline fixture
No gateway compatibility claim.
